const { pool } = require('../db');

const getWeekNumber = (date) => {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() + 4 - (d.getDay() || 7));
  const yearStart = new Date(d.getFullYear(), 0, 1);
  return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
};

const getAll = async (req, res) => {
  const { mes, anio, tipo, categoria, limit = 50, offset = 0 } = req.query;
  try {
    let query = `SELECT m.*, c.icono, c.color as cat_color
      FROM movimientos m
      LEFT JOIN categorias c ON c.nombre = m.categoria AND (c.usuario_id = m.usuario_id OR c.usuario_id IS NULL)
      WHERE m.usuario_id = $1`;
    const params = [req.userId];
    let i = 2;

    if (mes) { query += ` AND m.mes_num = $${i++}`; params.push(mes); }
    if (anio) { query += ` AND m.anio_num = $${i++}`; params.push(anio); }
    if (tipo) { query += ` AND m.tipo = $${i++}`; params.push(tipo); }
    if (categoria) { query += ` AND m.categoria = $${i++}`; params.push(categoria); }

    query += ` ORDER BY m.fecha DESC, m.created_at DESC LIMIT $${i++} OFFSET $${i}`;
    params.push(limit, offset);

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error obteniendo movimientos' });
  }
};

const create = async (req, res) => {
  const { tipo, monto, categoria, descripcion, fecha } = req.body;
  if (!tipo || !monto || !categoria) return res.status(400).json({ error: 'tipo, monto y categoría requeridos' });

  const fechaFinal = fecha ? new Date(fecha) : new Date();
  const semana = getWeekNumber(fechaFinal);
  const mes = fechaFinal.getMonth() + 1;
  const anio = fechaFinal.getFullYear();

  try {
    const result = await pool.query(
      `INSERT INTO movimientos (usuario_id, tipo, monto, categoria, descripcion, fecha, semana_num, mes_num, anio_num)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [req.userId, tipo, monto, categoria, descripcion || '', fechaFinal, semana, mes, anio]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error creando movimiento' });
  }
};

const update = async (req, res) => {
  const { id } = req.params;
  const { tipo, monto, categoria, descripcion, fecha } = req.body;
  try {
    const result = await pool.query(
      `UPDATE movimientos SET tipo=$1, monto=$2, categoria=$3, descripcion=$4, fecha=$5
       WHERE id=$6 AND usuario_id=$7 RETURNING *`,
      [tipo, monto, categoria, descripcion, fecha, id, req.userId]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Movimiento no encontrado' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Error actualizando movimiento' });
  }
};

const remove = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query('DELETE FROM movimientos WHERE id=$1 AND usuario_id=$2 RETURNING id', [id, req.userId]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Movimiento no encontrado' });
    res.json({ deleted: true });
  } catch (err) {
    res.status(500).json({ error: 'Error eliminando movimiento' });
  }
};

const getResumen = async (req, res) => {
  const { mes, anio } = req.query;
  const mesActual = mes || new Date().getMonth() + 1;
  const anioActual = anio || new Date().getFullYear();

  try {
    const [totales, porCategoria, porSemana] = await Promise.all([
      pool.query(
        `SELECT tipo, SUM(monto) as total FROM movimientos
         WHERE usuario_id=$1 AND mes_num=$2 AND anio_num=$3 GROUP BY tipo`,
        [req.userId, mesActual, anioActual]
      ),
      pool.query(
        `SELECT categoria, tipo, SUM(monto) as total, COUNT(*) as cantidad
         FROM movimientos WHERE usuario_id=$1 AND mes_num=$2 AND anio_num=$3
         GROUP BY categoria, tipo ORDER BY total DESC`,
        [req.userId, mesActual, anioActual]
      ),
      pool.query(
        `SELECT semana_num, tipo, SUM(monto) as total
         FROM movimientos WHERE usuario_id=$1 AND mes_num=$2 AND anio_num=$3
         GROUP BY semana_num, tipo ORDER BY semana_num`,
        [req.userId, mesActual, anioActual]
      ),
    ]);

    const ingresos = totales.rows.find(r => r.tipo === 'ingreso')?.total || 0;
    const gastos = totales.rows.find(r => r.tipo === 'gasto')?.total || 0;

    res.json({
      ingresos: parseFloat(ingresos),
      gastos: parseFloat(gastos),
      balance: parseFloat(ingresos) - parseFloat(gastos),
      porCategoria: porCategoria.rows,
      porSemana: porSemana.rows,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error obteniendo resumen' });
  }
};

module.exports = { getAll, create, update, remove, getResumen };
