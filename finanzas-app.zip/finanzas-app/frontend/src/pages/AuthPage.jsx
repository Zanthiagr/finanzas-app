import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function AuthPage() {
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ nombre: '', email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const { login, register } = useAuth();
  const navigate = useNavigate();

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === 'login') {
        await login(form.email, form.password);
      } else {
        if (!form.nombre) return toast.error('Tu nombre es requerido');
        await register(form.nombre, form.email, form.password);
      }
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Error al iniciar sesión');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-g-800 flex">
      {/* Left panel */}
      <div className="hidden lg:flex flex-col justify-between w-[420px] flex-shrink-0 p-10 bg-g-900">
        <div>
          <div className="flex items-center gap-2 mb-12">
            <div className="w-2.5 h-2.5 rounded-full bg-gold" />
            <span className="text-white font-medium text-lg">Fintual</span>
          </div>
          <h2 className="text-3xl font-medium text-white leading-snug mb-4">
            No es una app de finanzas.<br />
            <span className="text-gold">Es tu camino a la libertad.</span>
          </h2>
          <p className="text-white/45 text-sm leading-relaxed">
            Diseñada para personas que ya decidieron crecer — sin importar desde dónde empiecen.
            Controla, aprende, crece.
          </p>
        </div>

        <div className="space-y-4">
          {[
            { icon: 'ti-chart-line', text: 'Control total de ingresos, gastos y deudas' },
            { icon: 'ti-brain',      text: 'Reprogramación mental y hábitos financieros' },
            { icon: 'ti-school',     text: 'Academia con conocimiento real y calculadoras' },
            { icon: 'ti-target',     text: 'Metas visuales y cierre semanal guiado' },
          ].map((f, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-g-700 flex items-center justify-center">
                <i className={`ti ${f.icon} text-g-200 text-sm`} />
              </div>
              <span className="text-white/60 text-sm">{f.text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Right panel - form */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="flex items-center gap-2 mb-8 lg:hidden">
            <div className="w-2 h-2 rounded-full bg-gold" />
            <span className="text-white font-medium">Fintual</span>
          </div>

          <h3 className="text-xl font-medium text-white mb-1">
            {mode === 'login' ? 'Bienvenido de vuelta' : 'Empieza tu camino'}
          </h3>
          <p className="text-white/40 text-sm mb-6">
            {mode === 'login' ? 'Ingresa a tu cuenta' : 'Crea tu cuenta gratuita'}
          </p>

          <form onSubmit={submit} className="space-y-3">
            {mode === 'register' && (
              <input
                className="w-full bg-white/8 border border-white/15 rounded-xl px-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:border-gold/60"
                placeholder="Tu nombre"
                value={form.nombre}
                onChange={set('nombre')}
              />
            )}
            <input
              type="email"
              className="w-full bg-white/8 border border-white/15 rounded-xl px-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:border-gold/60"
              placeholder="Email"
              value={form.email}
              onChange={set('email')}
              required
            />
            <input
              type="password"
              className="w-full bg-white/8 border border-white/15 rounded-xl px-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:border-gold/60"
              placeholder="Contraseña"
              value={form.password}
              onChange={set('password')}
              required
              minLength={6}
            />
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gold text-g-900 font-semibold py-3 rounded-xl text-sm hover:bg-gold-dark transition-colors disabled:opacity-60 mt-1"
            >
              {loading ? 'Cargando...' : mode === 'login' ? 'Ingresar' : 'Crear cuenta'}
            </button>
          </form>

          <p className="text-center text-white/40 text-sm mt-5">
            {mode === 'login' ? '¿No tienes cuenta? ' : '¿Ya tienes cuenta? '}
            <button
              onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
              className="text-gold hover:text-gold-light transition-colors underline underline-offset-2"
            >
              {mode === 'login' ? 'Regístrate gratis' : 'Inicia sesión'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
